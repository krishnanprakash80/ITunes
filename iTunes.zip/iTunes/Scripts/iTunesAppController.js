﻿var app = angular.module("iTunesApp", []);

app.controller("iTunesAppController",["$scope","$http", '$sce', function($scope, $http, $sce) {
    $scope.searchFor = "Jack Johnson";
    $scope.mediaType = "musicTrack";
    $scope.filterTerm = "";
    $scope.sortProp = "collectionPrice";
    $scope.showVideo = false;
    $scope.searching = false;
    $scope.previewUrl = null;
	$scope.onFolderNumberKeyPress = function (event) {
		if (event.charCode == 13 || event.charCode == 10) //if enter then hit the search button
			$scope.doSearch();
	}
	$scope.doSearch = function () {
        $scope.closeVideo();
        $scope.mediaResults = [];
        $scope.lookupResults = [];
        $scope.searching = true;
        var type = ($scope.mediaType === "all") ? "" : $scope.mediaType;
        $http
          .jsonp('https://itunes.apple.com/search', { params: { term: $scope.searchFor, entity: type, callback: 'JSON_CALLBACK' } })
          .success(function (response) { $scope.mediaResults = response.results; })
          .finally(function () { $scope.searching = false; });
    };

    $scope.doLookup = function (lookupName, lookupValue) {
        $scope.closeVideo();
        $scope.lookupResults = [];
        $scope.searching = true;
        var type = ($scope.mediaType === "all") ? "" : $scope.mediaType;
        $http
          .jsonp('https://itunes.apple.com/lookup', { params: { id: lookupValue, callback: 'JSON_CALLBACK' } })
          .success(function (response) { $scope.lookupResults = response.results; })
          .finally(function () { $scope.searching = false; });
    };

    $scope.goBacktoSearchResuts = function () {
        $scope.lookupResults = [];
    }

    $scope.playVideo = function (item) {
        $scope.title = item.trackName || item.collectionName;
        $scope.artist = item.artistName;
        $scope.previewUrl = $sce.trustAsResourceUrl(item.previewUrl);
        $scope.showVideo = true;
    };

    $scope.closeVideo = function () {
        $scope.previewUrl = "";
        $scope.showVideo = false;
    };
}]);

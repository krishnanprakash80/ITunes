﻿'use strict'
angular.module("iTunesApp", []);
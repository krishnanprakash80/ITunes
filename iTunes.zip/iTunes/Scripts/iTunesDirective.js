﻿app.directive('playvideo', function () {
    return {
        restrict: 'E',
        replace: true,
        template: '<video type="video/mp4"></video>',
        link: function (scope, element, attributes) {
            attributes.$observe('src', function (val) {
                if (val) { element[0].load(); element[0].play(); }
                else { element[0].pause(); }
            });
        }
    };
});
